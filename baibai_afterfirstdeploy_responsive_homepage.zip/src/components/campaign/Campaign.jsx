import React from 'react'
import './Campaign.css'
export default function Campaign() {
  return (
    <div>
        <h1>This is Champaign Page</h1>
    </div>
  )
}
