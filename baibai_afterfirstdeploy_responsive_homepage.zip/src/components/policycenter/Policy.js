import React from 'react'
import './Policy.css'

const Policy = () => {
  return (
    <div className='container'>
      <div className='row'>
        <div className='col-md-2'>
          <ul>
            <li>
              
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default Policy