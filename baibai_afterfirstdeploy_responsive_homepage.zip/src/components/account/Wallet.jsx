import React from 'react'

const Wallet = () => {
  return (
    <div>Wallet</div>
  )
}

export default Wallet