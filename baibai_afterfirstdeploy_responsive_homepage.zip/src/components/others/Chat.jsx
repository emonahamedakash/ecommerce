import React from 'react'

export default function Chat() {
  return (
    <div>
        <h1>Chat</h1>
    </div>
  )
}
