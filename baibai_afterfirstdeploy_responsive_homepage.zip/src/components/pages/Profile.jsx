import React from "react";
import "./Profile.css";
import EditProfile from "../account/EditProfile";
import Orders from "../account/Orders";
import Wallet from "../account/Wallet";
import Col from "react-bootstrap/Col";
import ListGroup from "react-bootstrap/ListGroup";
import Row from "react-bootstrap/Row";
import Tab from "react-bootstrap/Tab";
export const Profile = () => {
  return (
    <div className="">
      <div className="profile container">
        <Tab.Container
          id="list-group-tabs-example"
          defaultActiveKey="#edit-profile"
        >
          <Row>
            <Col sm={3}>
              <ListGroup>
                <ListGroup.Item action href="#edit-profile">
                  Edit Profile
                </ListGroup.Item>
                <ListGroup.Item action href="#orders">
                  Orders
                </ListGroup.Item>
                <ListGroup.Item action href="#wallet">
                  Wallet
                </ListGroup.Item>
              </ListGroup>
            </Col>
            <Col sm={9}>
              <Tab.Content>
                <Tab.Pane eventKey="#edit-profile">
                  <EditProfile />
                </Tab.Pane>
                <Tab.Pane eventKey="#orders">
                  <Orders />
                </Tab.Pane>
                <Tab.Pane eventKey="#wallet">
                  <Wallet />
                </Tab.Pane>
              </Tab.Content>
            </Col>
          </Row>
        </Tab.Container>
      </div>
    </div>
  );
};
export default Profile;
