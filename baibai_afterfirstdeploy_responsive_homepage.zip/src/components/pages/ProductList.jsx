import React from 'react'
import ProductCard from '../shop/ProductCard'

const ProductList = () => {
  return (
    <div>ProductList</div>
  )
}

export default ProductList