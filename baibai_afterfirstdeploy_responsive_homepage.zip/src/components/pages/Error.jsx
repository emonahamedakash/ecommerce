import React from 'react'

const Error = () => {
  return (
    <div>
        <h1>
        Error!... try again...
        </h1>
        </div>
  )
}

export default Error