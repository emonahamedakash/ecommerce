// import { BASE_URL } from '../baseUrl';
// import { Login } from './account/Login';
// import { Register } from './account/Register';
// import { Terms } from './account/Terms';
// import { Campaign } from './campaign/Campaign';
// import { Checkout } from './cart/Checkout';
// import { Wishlist } from './cart/Wishlist';
// import { AllCategory } from './category/AllCategory';
// // import {  } from './'
// import { Header } from './home/header/Header';
// import { Navbar } from './home/header/Navbar';
// import { Slider } from './home/Slider';
// import { About } from './others/About';
// import { Contact } from './others/Contact';
// import { Policy } from './policycenter/Policy';
// import { ProductCard } from './shop/ProductCard';
// import { ProductList } from './shop/ProductList';
// import { VendorRegister } from './vendor/VendorRegister';
// //Pages
// import { Category } from './pages/Category';
// import { Home } from './pages/Home';
// import { ProductDetails } from './pages/ProductDetails';
// import { Profile } from './pages/Profile';

// export default{
//     Login,
//     Register, 
//     Terms, 
//     Campaign,
//     Checkout,
//     Wishlist,
//     AllCategory,
//     Header,
//     Navbar,
//     Slider,
//     About,
//     Contact,
//     Policy,
//     ProductCard,
//     ProductList,
//     VendorRegister,
//     Category,
//     Home,
//     ProductDetails,
//     Profile
// }
