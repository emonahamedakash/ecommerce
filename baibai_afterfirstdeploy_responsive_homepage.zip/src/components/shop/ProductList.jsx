import React from 'react'

const Productlist = () => {
    let products = {
        id : 1,
        title : "Watch",
        
        
    }
  return (
    <div>
        
    </div>
  )
}

export default Productlist