import React, { useState, useEffect } from "react";
import "./CategoryCard.css";
import CategoryCard from "./CategoryCard";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../../baseUrl";
import Loader from "../Loader";

export const AllManufacturer = () => {
  const [manufacturers, setManufacturers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  //Store fetching from here
  useEffect(() => {
    fetchManufacturers().then();
  }, []);

  const fetchManufacturers = async () => {
    setIsLoading(true);
    await axios
      .get(`${BASE_URL}/api/v1/manufacturer/list/all`)
      .then((response) => {
        let temp = [];
        response.data.data.forEach((item) => {
          temp.push(item);
        });
        setManufacturers(temp);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };
  //Store fetching end
  const navigateManufacturer = useNavigate();

  return (
    <div className="container" style={{ height: "70vh" }}>
      {isLoading ? (
        <Loader />
      ) : (
        <div className="row category">
          {manufacturers.map((manufacturer) => {
            return (
              <div className="col-sm categoryLink categoryCard">
                <CategoryCard
                  image={`${BASE_URL}${manufacturer.image.imageUrl}`}
                  name={manufacturer.name}
                  onClick={() =>
                    navigateManufacturer("manufacturer", {
                      state: { mName: manufacturer.name },
                    })
                  }
                />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default AllManufacturer;
