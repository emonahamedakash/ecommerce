import React, { useState, useEffect } from "react";
import "./CategoryCard.css";
import CategoryCard from "./CategoryCard";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../../baseUrl";
import Loader from "../Loader";

export const AllStore = () => {
  const [stores, setStores] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  //Store fetching from here
  useEffect(() => {
    fetchStores().then();
  }, []);

  const fetchStores = async () => {
    setIsLoading(true);
    await axios
      .get(`${BASE_URL}/api/v1/store/list/all`)
      .then((response) => {
        let temp = [];
        response.data.data.forEach((item) => {
          temp.push(item);
        });
        setStores(temp);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };
  //Store fetching end
  const navigateStore = useNavigate();

  return (
    <div className="container" style={{ height: "70vh" }}>
      {isLoading ? (
        <Loader />
      ) : (
        <div className="row category">
          {stores.map((store) => {
            return (
              <div className="col-sm categoryLink categoryCard">
                <CategoryCard
                  image={`${BASE_URL}${store.storeLogoThumbnailUrl}`}
                  name={store.name}
                  onClick={() =>
                    navigateStore("store", { state: { sName: store.name } })
                  }
                />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default AllStore;
